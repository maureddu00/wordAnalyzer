Il codice è stato sviluppato con l'IDE "INTELLIJ", spring boot di versione 3.2.0, Apache Maven 3.9.5 e java 21.

Per avviare l'applicazione, usare il comando mvn spring-boot:run o sfruttare il run/debug configurator. Una volta avviata, l'applicazione sarà accessibile tramite il browser all'indirizzo http://localhost:8080/.

Le prove sono state fatte sfruttando Postman.

Gli endpoint sono: 

"/analyze?word" per il metodo GET;
"/compare" per il metodo POST.
