package com.example.wordAnalyzer;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController //Annotazione per gestire le richieste RESTful
public class WordsCompare {

    // Endpoint per confrontare due parole
    @PostMapping("/compare") //Annotazione per mappare richieste HTTP di tipo POST
    public ResponseEntity<Map<String, Object>> compareWords(@RequestBody Map<String, String> words) {
        Map<String, Object> comparisonResult = new HashMap<>();

        // Verifico se sono state fornite esattamente due parole
        if (words == null || words.size() != 2)
        {
            //verifico se l'oggetto words, contenente le parole fornite nella richiesta, è nullo o se la sua
            //dimensione (numero di parole fornite) non è esattamente uguale a due. Se il controllo rileva che non ci
            //sono esattamente due parole verrà fornito uno status HTTP di errore (BadRequest)con un messaggio di errore
            comparisonResult.put("error", "Please provide exactly two words");
            return ResponseEntity.badRequest().body(comparisonResult);
        }

        //Ricavo le parole dall'oggetto words
        String firstWord = words.get("firstWord");
        String secondWord = words.get("secondWord");

        // Verifico se le parole sono vuote o nulle
        if (firstWord == null || firstWord.trim().isEmpty() || secondWord == null || secondWord.trim().isEmpty())
        {
            //Nel caso lo siano restituisco un messaggio di errore
            comparisonResult.put("error", "Words cannot be empty or null");
            return ResponseEntity.badRequest().body(comparisonResult);
        }

        // Calcolo la similarità tra le due parole in una classe apposita
        WordsCompareResponse wordsCompareResponse = new WordsCompareResponse(firstWord, secondWord);
        double wordSimilarity = wordsCompareResponse.SimilarityIndex();

        comparisonResult.put("FirstWord", firstWord);
        comparisonResult.put("SecondWord", secondWord);
        comparisonResult.put("WordSimilarity", wordSimilarity);

        //restituisco una risposta con uno status HTTP di successo (OK) e il corpo della risposta contiene la mappa
        //comparisonResult che contiene le parole e il valore dell'indice di similarità tra di esse
        return ResponseEntity.ok(comparisonResult);
    }


}


