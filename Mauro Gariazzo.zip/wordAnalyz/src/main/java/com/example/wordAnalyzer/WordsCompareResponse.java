package com.example.wordAnalyzer;
public class WordsCompareResponse
{
    String firstWord, secondWord;
    // Costruttore che prende in input le due parole da confrontare
    public WordsCompareResponse(String firstWord, String secondWord)
    {
        this.firstWord = firstWord;
        this.secondWord = secondWord;
    }

    // Metodo per calcolare l'indice di similarità tra le due parole
    public double SimilarityIndex()
    {
        //calcolo la lunghezza della parola più piccola e di quella più grande e in difference_length salvo la
        //differenza fra le 2 lunghezze
        int min_length = Math.min(firstWord.length(), secondWord.length());
        int max_length = Math.max(firstWord.length(), secondWord.length());
        int difference_length = max_length - min_length;

        //eseguo un ciclo per verificare se ogni carattere in posizione i della parola firstWord è diversa al
        //carattere in posizione i della parola secondWord, in tal modo ottengo il numero di caratteri diversi.
        //Logicamente il ciclo viene eseguito sulla lunghezza della parola più corta per evitare l'eccezione
        int characterDiff = 0;
        for (int i = 0; i < min_length; i++)
        {
            if (firstWord.charAt(i) != secondWord.charAt(i)) {
                characterDiff++;
            }
        }
        //Parto usando 1 che è l'indice di similarità più alto previsto e sottraggo la differenza tra lunghezze e
        //caratteri diversi dividendo il tutto per la lunghezza della parola più lunga

        return 1.0 - ((double) (difference_length + characterDiff) / max_length);
    }
}

//La divisione ((difference_length + characterDiff) / max_length) calcola una sorta di rapporto o proporzione
// delle differenze rispetto alla lunghezza massima tra le parole, ottenendo un indice di diversità tra le due parole.

// Il risultato sarà un valore compreso tra 0 e 1, in cui:
//Se le differenze tra le parole sono basse rispetto alla lunghezza massima, il valore sarà più vicino a 1,
// indicando una maggiore similarità tra le parole.
//
//Se le differenze tra le parole sono significative rispetto alla lunghezza massima, il valore sarà più basso,
// indicando una maggiore dissimilarità tra le parole.
