package com.example.wordAnalyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class WordAnalyzerApplication
{
	public static void main(String[] args) {
		SpringApplication.run(WordAnalyzerApplication.class, args);
	}
}


