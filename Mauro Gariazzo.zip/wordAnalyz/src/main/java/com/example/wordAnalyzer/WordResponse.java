package com.example.wordAnalyzer;
import java.util.HashMap;
import java.util.Map;
public class WordResponse
{
    private String word;
    public WordResponse(String word)
    {
        this.word = word;
    }

    public String GetWord()
    {
        return this.word;
    }

    //metodo per verificare se la parola è palindroma
    public boolean checkIfPalindrome()
    {
        this.word = this.word.toLowerCase(); // Converti la parola in minuscolo
        String reversed = new StringBuilder(this.word).reverse().toString(); // Rovescia la parola
        return this.word.equals(reversed);
    }

    //metodo per contare le vocali
    public int countVowels()
    {
        int vowelCount = 0; //contatore vocali
        this.word = this.word.toLowerCase(); // Converte la stringa in minuscolo per considerare anche le vocali maiuscole

        //ciclo for per contare le vocali
        for (int i = 0; i < this.word.length(); i++)
        {
            char ch = this.word.charAt(i);
            //se il carattere è una vocale il contatore verrà incrementato
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowelCount++;
            }
        }

        return vowelCount;
    }

    //metodo per contare la frequenza di ciascun carattere che restituisce un oggetto mappa
    public Map<Character, Integer> calculateLetterFrequency()
    {
        //mappa che traccia il carattere e il numero di volte in cui questo è presente nella parola
        Map<Character, Integer> frequencies = new HashMap<>();

        //ciclo foreach per tutti i caratteri della parola
        for (char letter : this.word.toCharArray())
        {
            if (Character.isLetter(letter))
            {
                letter = Character.toLowerCase(letter); // Considera le lettere maiuscole e minuscole come uguali
                frequencies.put(letter, frequencies.getOrDefault(letter, 0) + 1);
            }
        }

        return frequencies;
    }
}
