package com.example.wordAnalyzer;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

@RestController //Annotazione per gestire le richieste RESTful
public class WordController {
        // Endpoint per l'analisi di una singola parola
        @GetMapping("/analyze") //annotazione per richieste HTTP GET inviate all'URL /analyze.
        public ResponseEntity<Map<String, Object>> analyzeWord(@RequestParam(required = false) String word)
        {
                //Creo un oggetto mappa che sarà utilizzato per memorizzare i risultati dell'analisi della parola
                Map<String, Object> analysisResult = new HashMap<>();

                // Controllo se la parola è mancante o vuota
                if (word == null || word.trim().isEmpty()) {
                        // Restituisco un errore se la parola è mancante o vuota
                        analysisResult.put("error", "Missing or empty 'word' parameter");
                        return ResponseEntity.badRequest().body(analysisResult);
                }

                try {
                        //Creo un oggetto response dove sono salvati i metodi per l'analisi della parola
                        WordResponse response = new WordResponse(word.trim());

                        // Ottiengo le informazioni sull'analisi della parola
                        analysisResult.put("Word", response.GetWord());
                        analysisResult.put("IsPalindrome", response.checkIfPalindrome());
                        analysisResult.put("TotalCharacters", response.GetWord().length());
                        analysisResult.put("VowelCount", response.countVowels());
                        analysisResult.put("ConsonantCount", response.GetWord().length() - response.countVowels());
                        analysisResult.put("LetterFrequency", response.calculateLetterFrequency());

                        //Restituisco una risposta dove specifico che la richiesta è andata a buon fine
                        return ResponseEntity.ok(analysisResult);
                }
                catch (Exception e)
                {
                        // Gestisco eventuali errori nell'analisi della parola
                        analysisResult.put("error", "Error analyzing word: " + e.getMessage());
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(analysisResult);
                }
        }
}
